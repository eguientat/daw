<?php 
session_start();
if(isset($_SESSION['studentVerification']))
    header("Location:src/pages/home.php");
else
    header("Location:src/pages/signin.php");
    
?>