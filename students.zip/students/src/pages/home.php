<?php include("../templates/header.php"); ?>
<h1>Init</h1>
<?php include("../templates/footer.php"); ?>