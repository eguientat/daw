<?php
$dbHost="localhost";
$db="daw_project";
$dbUser="root";
$dbPassword="root";

$conection="";
try{
    $conection=new PDO("mysql:host=$dbHost;dbname=$db",$dbUser,$dbPassword,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $conection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(Exception $ex){
    echo $ex->getMessage();
}

